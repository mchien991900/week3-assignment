import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
const CHOICES = [
  { name: 'Rock', uri: 'http://pngimg.com/uploads/stone/stone_PNG13622.png' },
  { name: 'Paper', uri: 'https://www.stickpng.com/assets/images/5887c26cbc2fc2ef3a186046.png', },
  { name: 'Scissors', uri: 'http://pluspng.com/img-png/png-hairdressing-scissors-beauty-salon-scissors-clipart-4704.png', },
];
function PlayerDecision(props) {
  return CHOICES.map(item => {
        return (
        <TouchableOpacity style={styles.ButtonFormat} onPress={() => props.onPressButton(item.name)}>
          <Text style={styles.TextButtonFormat}>
          {item.name}
          </Text>
        </TouchableOpacity>
        )
      })
    }
export default PlayerDecision;

const styles = StyleSheet.create({
  ButtonFormat: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    width: 200,
    height: 40,
    borderColor: 'brown',
    borderWidth: 2,
    borderRadius: 10,
    backgroundColor: 'brown'
  },
  TextButtonFormat: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold'
  }
})