import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

function BattleGround(props) {
  return (
    <View style={styles.Button}>
      <Text>{props.playerName}</Text>
      <Image
        source={{ uri: props.choice.uri}} 
        resizeMode="contain"
        style={styles.image}/>
      <Text>{props.choice.name}</Text>
    </View>
  );
}

export default BattleGround;

const styles = StyleSheet.create({
  Button: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  image: {
    height: 150,
    width: 150
  }
})
