import { CHOICES } from './Constants';

const randomComputerChoice = () =>
  CHOICES[Math.floor(Math.random() * CHOICES.length)];

const getRoundOutcome = (userChoice, computerChoice) => {
  let resultText;

  if (userChoice === 'Rock') {
    resultText = computerChoice === 'Scissors' ? 'Victory!' : 'Defeat!';
  }
  if (userChoice === 'Paper') {
    resultText = computerChoice === 'Rock' ? 'Victory!' : 'Defeat!';
  }
  if (userChoice === 'Cissors') {
    resultText = computerChoice === 'Paper' ? 'Victory!' : 'Defeat!';
  }

  if (userChoice === computerChoice) resultText = 'Tie game!';
  return resultText;
};

export { randomComputerChoice, getRoundOutcome };