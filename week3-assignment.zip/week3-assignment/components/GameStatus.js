import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

function GameStatus(props) {
  return (
    <View>
      <Text style= {styles.ResultTextFormat}>{props.Result}</Text>
    </View>
  );
}

export default GameStatus;
const styles = StyleSheet.create ({
  ResultTextFormat: {
    fontSize: 30,
  }
})